import pandas as pd
from sqlalchemy import create_engine

df = pd.read_csv('restaurant_ds.csv')
engine = create_engine('mysql+mysqlconnector://root:Anwesha123%40@localhost/swiggy_db')
df.to_sql("restaurant_cleaned", con=engine, if_exists='replace', index=False)
print(df.head())
print(df.shape)
print("Data loaded successfully into MySQL database.")

df1 = pd.read_csv('exploded_cuisine.csv')
print(df1.head())
print(df1.shape)
engine = create_engine('mysql+mysqlconnector://root:Anwesha123%40@localhost/swiggy_db')
df1.to_sql("exploded_cuisine", con=engine, if_exists='replace', index=False)

df2 = pd.read_csv('primary_cuisine.csv')
print(df2.head())
print(df2.shape)
engine = create_engine('mysql+mysqlconnector://root:Anwesha123%40@localhost/swiggy_db')
df2.to_sql("primary_cuisine", con=engine, if_exists='replace', index=False)
